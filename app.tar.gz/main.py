import locale
import flet as fl
from flet_core import KeyboardType

locale.setlocale(locale.LC_ALL, 'pt_BR.UTF-8')


last_valid_value = ""


def main(page):
    page.title = "Combustivel"
    page.vertical_alignment = fl.MainAxisAlignment.CENTER
    page.horizontal_alignment = fl.CrossAxisAlignment.CENTER

    def calc(e):
        val1 = float(etanol.value)
        val2 = float(gasolina.value)

        res = val1/val2
        if res <= 0.7:
            resultado.value = 'Etanol'

        else:
            resultado.value = 'Gasolina'

        page.update()


    # Criando os elementos da interface
    gasolina = fl.TextField(value="", hint_text="0.00", label="Gasolina (R$)", width=100, keyboard_type=KeyboardType.NUMBER)
    etanol = fl.TextField(value="", label="Etanol (R$)", hint_text="0.00",  width=100, keyboard_type=KeyboardType.NUMBER)
    calcular = fl.ElevatedButton("Calcular", on_click=calc)
    resultado = fl.Text('')



    # Organizando os elementos em layout
    page.add(fl.Column(
        [
            gasolina,
            etanol,
            calcular,
            resultado,
        ],
        alignment=fl.MainAxisAlignment.CENTER
    ))


fl.app(target=main)
